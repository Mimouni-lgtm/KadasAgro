export default function Footer(){
return (<footer className='bg-green-700 text-white p-4 text-center'>&copy; 2025 KADAsAgri</footer>);
}