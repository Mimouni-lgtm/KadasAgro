export default function Header(){
return (<header className='bg-green-700 text-white p-4 text-center text-xl font-bold'>KADAsAgri</header>);
}