import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Home(){
return (
<>
<Header/>
<main className='p-6'>
<h1 className='text-3xl font-bold'>Bienvenue à KADAsAgri</h1>
<p>Production agricole & élevage laitier.</p>
</main>
<Footer/>
</>
)
}
